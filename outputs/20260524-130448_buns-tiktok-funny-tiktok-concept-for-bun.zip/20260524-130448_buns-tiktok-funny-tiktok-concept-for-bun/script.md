_Review script._

**Script:**
(0:00-0:05)  
[Visual: Close-up of Buns staring out the window]  
**Buns (V.O.):** "Every new follower could mean a can of tuna... Right?"

(0:06-0:10)  
[Visual: Quick cut to an empty tuna can]  
**Buns (V.O.):** "My dad says it's true, but where are my followers?"

(0:11-0:15)  
[Visual: Wide shot of Buns pacing]  
**Buns (V.O.):** "It's a dire situation—tuna or death. The stakes have never been higher."

(0:16-0:20)  
[Visual: Dramatic pause, looking at camera]  
**Buns (V.O.):** "What if I never get that tuna? What will become of me?"

(0:21-0:25)  
[Visual: Buns strikes a dramatic pose]  
**Buns (V.O.):** "So follow me, humans! For the love of tuna!"

---