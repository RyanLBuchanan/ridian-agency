_Review posting checklist._

- [ ] Final review (hook, captions, watermark, sound)
- [ ] Aspect ratio / resolution check (9:16 for TikTok)
- [ ] First-comment plan (consider pinning a comment with a fun fact about Buns)
- [ ] Best posting window for TikTok (typically evenings or weekends)
- [ ] Cross-post / repurpose checklist (Instagram Stories)
- [ ] Track-back: what to watch in the first 24-48 hours (engagement metrics, follower growth)